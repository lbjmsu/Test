﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam1ProgrammingQuestion
{
    internal interface IBudgeting
    {
        public string BudgetingStandards();

        public int YearlyBudget();
    }
}
